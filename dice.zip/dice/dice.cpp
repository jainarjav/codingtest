#include <iostream>
#include <ctime>
#include <conio.h>
#include <random>

using namespace std;

  int total(int sum)
{
	int roll_1;
	int roll_2;
	int totalset;
	
	int counter =0;
	
	while (totalset!=sum)
	{
	
	roll_1=rand()%5+1;
	roll_2=rand()%5+1;
	totalset=roll_1+roll_2;
	counter++;
	cout << totalset << endl; 
	}
	return counter;

}
int main()
{
	srand((unsigned) time(0)); 
	cout<<"It will roll the dice according to number comes";
	cout<<"Enter the sum ";

	int n, dice;
	cin>>n;
		while(n<3 || n>15)
		{
			cout<<"Invalid result";
			cin>>n;
		}
	dice =	total (n);
	cout<<"\n\tThe number of times you rolled to obtain the sum of " << n<< " is: " << dice;
	_getch();
	return 0;
}