#include<iostream>
using namespace std;

int main()

{
	int basepoint = 100;
	int premium_value = basepoint;
	int age;
	int Account_insurance;
	double sum = 0;
	int mainCategory;
	const int category1 = 1;
	const int category2 = 2;
	
	do
	{
		cout << "\n\t\t>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n\n";
		cout << "\t\t*Car premium insurance calculator*" << endl;
		cout << "\n\t\t<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n\n"<<endl;
		cout << "1.Calculate the car insurance premium"<<endl;
		cout << "2.Exit the program"<<endl;
		cout << "Enter you category :";
		cin >> mainCategory;
		switch (mainCategory)
		{
		case 1:
			cout << "Enter age of the candidate: ";
			cin >> age;
			if (age<50)
			{
				premium_value += 100;
				
			}
			else if (age<40||age>20)
			{
				premium_value += 20;
			}

			cout << "count of accidents: ";
			cin >> Account_insurance;
			if (Account_insurance==1)
			{
				cout << "The total premium_value: " << premium_value<< endl;
				break;
			}
			else if (Account_insurance<3)
			{
				int prem_1 = premium_value + (50 * premium_value);
				cout << "The total premium: " << prem_1 << endl;
				break;
			}
			else if (Account_insurance == 5 || Account_insurance <= 6)
			{
				int prem_2 = premium_value + (60 * Account_insurance);
				cout << "The total premium_value: " << prem_2 << endl;
				break;
			}

			else if (Account_insurance > 45)
			{
				cout << "Sorry, insurance not available for customer"<< endl;
			}
	
		}

	}
	
	while (mainCategory!=0);
		return 0;


	system("PAUSE");
	return 1;
}